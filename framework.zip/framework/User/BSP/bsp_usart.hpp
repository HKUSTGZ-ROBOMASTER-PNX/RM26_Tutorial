#ifndef BSP_USART_HPP
#define BSP_USART_HPP

#include "main.h"
#include "string.h"
#include "stm32h7xx.h"
#include "usart.h"
#include "dma.h"

void USART_Init(void);

#endif //  __BSP_USART_H